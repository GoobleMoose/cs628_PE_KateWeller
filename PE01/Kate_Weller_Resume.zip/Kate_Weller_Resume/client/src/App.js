import logo from './logo.svg';
import './App.css';
import Resume from './Resume';

function App() {
  return (
    <div className="App">
      <Resume/>
    </div>
  );
}

export default App;
